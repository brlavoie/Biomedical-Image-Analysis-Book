% FILENAME: loadFile.m (FINAL VERSION
%
% PURPOSE: read different types of files and save the variables
% accordingly. This program can read '.CVI', '.EDG', '.BIN', '.PGM', '.TXT'
% The following are examples of how to call this program to read the
% different types of files.
%
% CVI
% [mammographicImage] = loadFile('c58_97roroi', '.cvi', 'ROIs');
% EDG
% [contour, numberOfContourPoints] = loadFile('c58_97roroi', '.edg',
% 'Contours');
% BIN
% [contour, numberOfContourPoints] = loadFile('c58_97roroi', '.edg',
% 'Contours');
% PGM
% [mask] = loadFile('c58_97roroi', '.pgm', 'Masks');
% TXT (this is mainly for the namelist.txt file
% [list, total] = loadFile('namelist', '.txt');
%
% INPUTS:
% 1) casename: a string containing the filename without the extension
% 2) extension: a string containing the extension of the file ('.CVI', 
% '.EDG', '.BIN', '.PGM', '.TXT')
% 3) folder: a string containing the folder name where the files are kept
%
% OUTPUTS:
% Depends on the file you're reading.
%
%
% Developed by: Thanh Nguyen
% Developed on: January 10, 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function varargout = loadFile(casename, extension, folder)



switch lower(extension)
    case {'.edg'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        fip = fopen(filename, 'r');
        kk=1;
        while feof(fip) == 0
            x(kk) = fscanf(fip, '%d', 1);
            y(kk) = fscanf(fip, '%d', 1);
            z(kk) = fscanf(fip, '%d', 1);
            kk = kk+1;
        end
        contour = [x(2:end); y(2:end)];
        numberOfContourPoints = x(1);
        varargout = {contour, numberOfContourPoints};
    case {'.bnd'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        temp = load(filename);
        contour = [temp(2:end, 1)'; temp(2:end, 2)'];
        numberOfContourPoints = temp(1,1);
        varargout = {contour, numberOfContourPoints};
    case {'.bin'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        temp = load(filename);
        contour = [temp(2:end, 1)'; temp(2:end, 2)'];
        numberOfContourPoints = temp(1,1);
        varargout = {contour, numberOfContourPoints};
    case {'.cvi'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        mammographicImage = readCVI(filename, 'uchar');
        varargout = {mammographicImage};
    case {'.pgm'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        mask = imread(filename);
        varargout = {mask};
    case {'.txt'}
        if nargin == 2
            filename = strcat(casename, extension);
        elseif nargin == 3
            filename = strcat(folder, '\', casename, extension);
        end
        list = textread(filename, '%s', 'delimiter', '\n', 'whitespace', '');
        list = char(list);
        total = size(list, 1);
        varargout = {list, total};
    otherwise
        disp('Unknown file type. Please ensure that the file extension is one of the following: ".edg" ".bin" ".cvi" ".pgm" "txt"');
end
