clear all
close all
% plot1: m23lc97, m62lx97, m63rc97, m63ro97, circ-fm-028, circ-gm-023, circ-gm-270, spic-dm-202, spic-fm-184
% first set: 9 malignant contours
 [m23lc97, numberOfContourPoints] = loadFile('C23_97LCROI', '.EDG', 'Contours57EDG');
 [m23lc97IMG] = loadFile('C23_97LCROI', '.cvi', 'MassROIs57CVI');
 [m62lx97, numberOfContourPoints] = loadFile('C62_97LAXMROI', '.EDG', 'Contours57EDG');
 [m62lx97IMG] = loadFile('C62_97LAXMROI', '.cvi', 'MassROIs57CVI');
 [m63rc97, numberOfContourPoints] = loadFile('C63_97RCROI', '.EDG', 'Contours57EDG');
 [m63rc97IMG] = loadFile('C63_97RCROI', '.cvi', 'MassROIs57CVI');
 [m63ro97, numberOfContourPoints] = loadFile('C63_97ROROI', '.EDG', 'Contours57EDG');
 [m63ro97IMG] = loadFile('C63_97ROROI', '.cvi', 'MassROIs57CVI');
 [circfm028, numberOfContourPoints] = loadFile('CIRC_FM_028', '.BND', 'Contours54BND');
 [circfm028IMG] = loadFile('CIRC_FM_028', '.cvi', 'MassROIs54CVI');
 [circgm023, numberOfContourPoints] = loadFile('CIRC_GM_023', '.BND', 'Contours54BND');
 [circgm023IMG] = loadFile('CIRC_GM_023', '.cvi', 'MassROIs54CVI');
 [circgm270, numberOfContourPoints] = loadFile('CIRC_GM_270', '.BND', 'Contours54BND');
 [circgm270IMG] = loadFile('CIRC_GM_270', '.cvi', 'MassROIs54CVI');
 [spicdm202, numberOfContourPoints] = loadFile('SPIC_DM_202', '.BND', 'Contours54BND');
 [spicdm202IMG] = loadFile('SPIC_DM_202', '.cvi', 'MassROIs54CVI');
 [spicfm184, numberOfContourPoints] = loadFile('SPIC_FM_184', '.BND', 'Contours54BND');
 [spicfm184IMG] = loadFile('SPIC_FM_184', '.cvi', 'MassROIs54CVI');

for xx=1:size(m23lc97,2)
    m23lc97IMG (m23lc97(2, xx), m23lc97(1, xx)) = 0;
end
for xx=1:size(m62lx97,2)
    m62lx97IMG (m62lx97(2, xx), m62lx97(1, xx)) = 0;
end
for xx=1:size(m63rc97,2)
    m63rc97IMG (m63rc97(2, xx), m63rc97(1, xx)) = 0;
end
for xx=1:size(m63ro97,2)
    m63ro97IMG (m63ro97(2, xx), m63ro97(1, xx)) = 0;
end
for xx=1:size(circfm028,2)
    circfm028IMG (circfm028(1, xx), circfm028(2, xx)) = 0;
end
for xx=1:size(circgm023,2)
    circgm023IMG (circgm023(1, xx), circgm023(2, xx)) = 0;
end
for xx=1:size(circgm270,2)
    circgm270IMG (circgm270(1, xx), circgm270(2, xx)) = 0;
end
for xx=1:size(spicdm202,2)
    spicdm202IMG (spicdm202(1, xx), spicdm202(2, xx)) = 0;
end
for xx=1:size(spicfm184,2)
    spicfm184IMG (spicfm184(1, xx), spicfm184(2, xx)) = 0;
end

 figure
 subplot(331)
 imshow(m23lc97IMG);
%  hold on;
%  plot (m23lc97(1,:), m23lc97(2,:));
%  axis off;axis equal;
 title ('m23lc97');
 subplot(332)
 imshow(m62lx97IMG);
%  hold on;
%  plot (m62lx97(1,:), m62lx97(2,:));
%  axis off; axis equal;
 title ('m62lx97');
 subplot(333)
 imshow(m63rc97IMG);
%  hold on;
%  plot (m63rc97(1,:), m63rc97(2,:));
%  axis off;axis equal;
 title ('m63rc97');
 subplot(334)
 imshow(m63ro97IMG);
%  hold on;
%  plot (m63ro97(1,:), m63ro97(2,:));
%  axis off;axis equal;
 title ('m63ro97');
 subplot(335)
 imshow(circfm028IMG);
%  hold on;
%  plot (circfm028(1,:), circfm028(2,:));
%  axis off;axis equal;
 title ('circ-fm-028');
  subplot(336)
  imshow(circgm023IMG);
%  hold on;
%  plot (circgm023(1,:), circgm023(2,:));
%  axis off;axis equal;
 title ('circ-gm-023');
  subplot(337)
  imshow(circgm270IMG);
%  hold on;
%  plot (circgm270(1,:), circgm270(2,:));
%  axis off;axis equal;
 title ('circ-gm-270');
  subplot(338)
  imshow(spicdm202IMG);
%  hold on;
%  plot (spicdm202(1,:), spicdm202(2,:));
%  axis off;axis equal;
 title ('spic-dm-202');
  subplot(339)
  imshow(spicfm184IMG);
%  hold on;
%  plot (spicfm184(1,:), spicfm184(2,:));
%  axis off;axis equal;
 title ('spic-fm-184');
 print -deps contours9m.eps
 
 % second set: 7 benign contours
 % plot2: spic-db-193, spic-db-198, spic-db-199, spic-db-207, spic-fb-195, spic-gb-175, spic-gb-188
 [spicdb193, numberOfContourPoints] = loadFile('SPIC_DB_193', '.BND', 'Contours54BND');
 [spicdb193IMG] = loadFile('SPIC_DB_193', '.cvi', 'MassROIs54CVI');
 [spicdb198, numberOfContourPoints] = loadFile('SPIC_DB_198', '.BND', 'Contours54BND');
 [spicdb198IMG] = loadFile('SPIC_DB_198', '.cvi', 'MassROIs54CVI');
 [spicdb199, numberOfContourPoints] = loadFile('SPIC_DB_199', '.BND', 'Contours54BND');
 [spicdb199IMG] = loadFile('SPIC_DB_199', '.cvi', 'MassROIs54CVI');
 [spicdb207, numberOfContourPoints] = loadFile('SPIC_DB_207', '.BND', 'Contours54BND');
 [spicdb207IMG] = loadFile('SPIC_DB_207', '.cvi', 'MassROIs54CVI');
 [spicfb195, numberOfContourPoints] = loadFile('SPIC_FB_195', '.BND', 'Contours54BND');
 [spicfb195IMG] = loadFile('SPIC_FB_195', '.cvi', 'MassROIs54CVI');
 [spicgb175, numberOfContourPoints] = loadFile('SPIC_GB_175', '.BND', 'Contours54BND');
 [spicgb175IMG] = loadFile('SPIC_GB_175', '.cvi', 'MassROIs54CVI');
 [spicgb188, numberOfContourPoints] = loadFile('SPIC_GB_188', '.BND', 'Contours54BND');
 [spicgb188IMG] = loadFile('SPIC_GB_188', '.cvi', 'MassROIs54CVI');
 for xx=1:size(spicdb193,2)
    spicdb193IMG (spicdb193(1, xx), spicdb193(2, xx)) = 0;
 end
for xx=1:size(spicdb198,2)
    spicdb198IMG (spicdb198(1, xx), spicdb198(2, xx)) = 0;
end
for xx=1:size(spicdb199,2)
    spicdb199IMG (spicdb199(1, xx), spicdb199(2, xx)) = 0;
end
for xx=1:size(spicgb175,2)
    spicgb175IMG (spicgb175(1, xx), spicgb175(2, xx)) = 0;
end
for xx=1:size(spicdb207,2)
    spicdb207IMG (spicdb207(1, xx), spicdb207(2, xx)) = 0;
end
for xx=1:size(spicfb195,2)
    spicfb195IMG (spicfb195(1, xx), spicfb195(2, xx)) = 0;
end
for xx=1:size(spicgb188,2)
    spicgb188IMG (spicgb188(1, xx), spicgb188(2, xx)) = 0;
end

 figure
 subplot(331)
 imshow(spicdb193IMG);
%  hold on;
%  plot (spicdb193(1,:), spicdb193(2,:));
%  axis off;axis equal;
 title ('spic-db-193');
 subplot(332)
 imshow(spicdb198IMG);
%  hold on;
%  plot (spicdb198(1,:), spicdb198(2,:));
%  axis off;axis equal;
 title ('spic-db-198');
 subplot(333)
 imshow(spicdb199IMG);
%  hold on;
%  plot (spicdb199(1,:), spicdb199(2,:));
 axis off;axis equal;
 title ('spic-db-199');
 subplot(334)
 imshow(spicdb207IMG);
%  hold on;
%  plot (spicdb207(1,:), spicdb207(2,:));
%  axis off;axis equal;
 title ('spic-db-207');
 subplot(335)
 imshow(spicfb195IMG);
%  hold on;
%  plot (spicfb195(1,:), spicfb195(2,:));
%  axis off;axis equal;
 title ('spic-fb-195');
 subplot(336)
 imshow(spicgb175IMG);
%  hold on;
%  plot (spicgb175(1,:), spicgb175(2,:));
%  axis off;axis equal;
 title ('spic-gb-175');
 subplot(337)
 imshow(spicgb188IMG);
%  hold on;
%  plot (spicgb188(1,:), spicgb188(2,:));
%  axis off;axis equal;
 title ('spic-gb-188');
 print -deps contours7b.eps