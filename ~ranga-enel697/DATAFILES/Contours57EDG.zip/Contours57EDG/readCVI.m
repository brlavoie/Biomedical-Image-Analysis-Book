function img = readCVI(filename, type)
%
% readCVI: reads a CVI file
%
% img = readCVI(filename, type)
%

fid = fopen(filename, 'r');

w1 = fread(fid, 1, 'uchar');
w2 = fread(fid, 1, 'uchar');
w3 = fread(fid, 1, 'uchar');
w4 = fread(fid, 1, 'uchar');
width = (2^24)*w1 + (2^16)*w2 + (2^8)*w3 + w4;

h1 = fread(fid, 1, 'uchar');
h2 = fread(fid, 1, 'uchar');
h3 = fread(fid, 1, 'uchar');
h4 = fread(fid, 1, 'uchar');
height = (2^24)*h1 + (2^16)*h2 + (2^8)*h3 + h4;

img = fread(fid, [width height], strcat(type, '=>', type));

img = img';

fclose(fid);